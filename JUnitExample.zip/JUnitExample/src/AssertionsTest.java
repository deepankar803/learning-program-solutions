public class AssertionsTest {
    public void testAssertions() {
        // Assert equals
        assertEquals("Sum of 2 + 3 should be 5", 5, 2 + 3);

        // Assert true
        assertTrue("5 should be greater than 3", 5 > 3);

        // Assert false
        assertFalse("5 should not be less than 3", 5 < 3);

        // Assert null
        assertNull("This should be null", null);

        // Assert not null
        assertNotNull("Object should not be null", new Object());
    }
}
